This is where the videos will be downloaded by the MXR system app. 

Use MXRStorage.GetFullPath(Video.videoPath) to get the asolute path to the videos and play them using the video player of your choice.