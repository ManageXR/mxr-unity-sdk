This is where the videos will be downloaded by the MXR system app. 

Use MXRStorage.GetFullPath(Video.videoPath) to get the path to the videos on disk and play it using the video player of your choice.