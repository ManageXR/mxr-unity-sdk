Branding images such as top logo, bottom logo and background 360 images

Use MXRStorage.GetFullPath(CustomLauncherImage.path) to get the absolute path to the branding images, load them and display them