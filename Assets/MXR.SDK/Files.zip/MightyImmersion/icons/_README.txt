This is where the content icons will be downloaded by the MXR system app. 

Use MXRStorage.GetFullPath(Video/RuntimeApp/WebXRApp.iconPath) to get the absolute path to the icons, load them and display